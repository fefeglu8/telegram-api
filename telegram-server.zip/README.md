# Telegram Server for Vercel

## Environment Variables
TELEGRAM_BOT_TOKEN=
TELEGRAM_TARGET_CHAT=

## Webhook:
https://api.telegram.org/bot<token>/setWebhook?url=https://your-app.vercel.app/api/telegram
